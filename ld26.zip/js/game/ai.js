define(['levels'], function(levels) {

  var ai = {};

  ai.takeTurn = function() {

  };

  return ai;
});
