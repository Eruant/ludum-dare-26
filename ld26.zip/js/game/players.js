define(function(){

	var players = [
		{ name: "Red player", color: "#f33", cpu: false },
		{ name: "Blue player", color: "#33f", cpu: true },
		{ name: "Green player", color: "#3f3", cpu: true },
	];

	return players;

});
